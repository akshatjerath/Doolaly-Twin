// Walking, in floor-plan pixels. No Three.js here.
// Every place is a path from the entrance, so going anywhere = back to the shared point, then out.
import { M_PER_PX, SEATS } from './plan';

export type Point = [number, number];
export type Path = Point[];

export const SPEED = 1.2 / M_PER_PX; // 1.2 m/s

const STREET: Point = [1440, 2090];
const OUTSIDE: Point = [842, 2090];
const DOOR: Point = [842, 1760];
const HALL: Point = [842, 1580];
const indoors = (...rest: Point[]): Path => [STREET, OUTSIDE, DOOR, HALL, ...rest];

const LEFT = 585; // aisle between the bar and the banquette chairs
const RIGHT = 1170; // aisle between the banquette and the window tables
const aisle = (x: number, y: number): Path => indoors([x, 1580], [x, y]);

// shortcut: bench seats are reached straight across their table; add gaps between tables if it shows.
export const SEAT_PATHS: Path[] = SEATS.map(([x, y, , height]) => {
  if (height > 0.5) return indoors([x, 1580], [x, y]); // bar stools
  if (y > 1400) return indoors([1130, 1580], [1215, 1585], [x, y]); // alcove
  const side = x < 857 ? LEFT : RIGHT;
  return [...aisle(side, y), [x, y]];
});

const range = <T>(n: number, f: (i: number) => T) => Array.from({ length: n }, (_, i) => f(i));

/** Today: a line out of the door and along the pavement. */
export const DOOR_LINE: Path[] = range(14, (i): Path =>
  i < 5 ? [STREET, OUTSIDE, [842, 1790 + i * 65]] : [STREET, [915 + (i - 5) * 62, 2090]]);
/** Ordering at the counter. */
export const TILL_LINE: Path[] = range(9, (i) => aisle(560, 1360 - i * 70));
/** Today: takeaway customers stand among the tables. */
export const AMONG: Path[] = range(18, (i) => aisle(i % 2 ? RIGHT + 45 : LEFT + 20, 790 + Math.floor(i / 2) * 78));
/** With changes: at the pickup shelf. */
export const SHELF: Path[] = range(12, (i) => indoors([350 + (i % 6) * 62, 1555 + Math.floor(i / 6) * 45]));
/** With changes: waiting away from the door. */
export const AWAY: Path[] = range(12, (i): Path => [STREET, OUTSIDE, [200, 2090], [100 + (i % 3) * 80, 1800 + Math.floor(i / 3) * 90]]);
/** Leaving: off the plot. */
export const GONE: Path = [STREET];

const same = (a: Point, b: Point) => a[0] === b[0] && a[1] === b[1];

/** Waypoints still to visit when going from the end of `from` to the end of `to`. */
export function route(from: Path, to: Path): Path {
  let shared = 0;
  while (shared < from.length && shared < to.length && same(from[shared], to[shared])) shared++;
  const back = from.slice(Math.max(shared - 1, 0), -1).reverse();
  return [...back, ...to.slice(shared)];
}

/** Move `at` along `todo` by at most `distance`, consuming reached waypoints. */
export function advance(at: Point, todo: Path, distance: number) {
  while (todo.length && distance > 0) {
    const dx = todo[0][0] - at[0];
    const dy = todo[0][1] - at[1];
    const left = Math.hypot(dx, dy);
    if (left <= distance) {
      [at[0], at[1]] = todo.shift()!;
      distance -= left;
    } else {
      at[0] += (dx / left) * distance;
      at[1] += (dy / left) * distance;
      distance = 0;
    }
  }
}
