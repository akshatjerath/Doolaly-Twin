// Turns simulation state into "who stands or sits where". No Three.js here.
import { SEATS } from './plan';
import type { Ghost, Party, Sim } from './sim';
import { AMONG, AWAY, DOOR_LINE, GONE, SEAT_PATHS, SHELF, TILL_LINE, type Path } from './walk';

export type State = 'seat' | 'takeaway' | 'seated' | 'left';
export type Crowd = {
  send(id: number, path: Path, state: State, seat?: [facing: number, height: number], now?: boolean): void;
  clear(): void;
};
type Want = { path: Path; state: State; seat?: number };

const members = (list: Party[]) => list.flatMap((p) => Array.from({ length: p.size }, (_, i) => ({ key: p.id * 8 + i, party: p.id })));

export function createSync(crowd: Crowd) {
  let shown = new Map<number, Want>();
  let partyOf = new Map<number, number>();
  const ghosts = new WeakSet<Ghost>();
  let balked = 0;

  return {
    /** Drop everyone, so the next call places people without walking. */
    reset() {
      shown = new Map();
      partyOf = new Map();
      crowd.clear();
    },
    /** Returns how many people had no free spot to be drawn in. */
    update(sim: Sim, now = false) {
      const scen = sim.scen;
      const want = new Map<number, Want>();
      let hidden = 0;
      const put = (list: Party[], spots: Path[], state: State) =>
        members(list).forEach(({ key }, i) => {
          if (i < spots.length) want.set(key, { path: spots[i], state });
          else hidden++;
        });
      put(sim.dineQ, scen.waitlist ? AWAY : DOOR_LINE, 'seat');
      put([...sim.tills.flatMap((t) => (t.p ? [t.p] : [])), ...sim.tillQ], TILL_LINE, 'takeaway');
      put(sim.prep, scen.shelf ? SHELF : AMONG, 'takeaway');

      // keep seats already held, then give new sitters the free seat nearest their party
      const sitting = members(sim.seated);
      const taken = new Set<number>();
      const partySeat = new Map<number, number>();
      for (const { key, party } of sitting) {
        const seat = shown.get(key)?.seat;
        if (seat === undefined) continue;
        taken.add(seat);
        partySeat.set(party, seat);
        want.set(key, shown.get(key)!);
      }
      for (const { key, party } of sitting) {
        if (want.has(key)) continue;
        const mate = partySeat.get(party);
        const near = (i: number) => (mate === undefined ? (i * 17) % 41 : Math.hypot(SEATS[i][0] - SEATS[mate][0], SEATS[i][1] - SEATS[mate][1]));
        let best = -1;
        for (let i = 0; i < Math.min(sim.cfg.seats, SEATS.length); i++) {
          if (!taken.has(i) && (best < 0 || near(i) < near(best))) best = i;
        }
        if (best < 0) {
          hidden++;
          continue;
        }
        taken.add(best);
        partySeat.set(party, best);
        want.set(key, { path: SEAT_PATHS[best], state: 'seated', seat: best });
      }
      partyOf = new Map(sitting.map((m) => [m.key, m.party]));

      for (const [key, w] of want) {
        const before = shown.get(key);
        if (before?.path === w.path && before.state === w.state) continue;
        crowd.send(key, w.path, w.state, w.seat === undefined ? undefined : [SEATS[w.seat][2], SEATS[w.seat][3]], now || undefined);
      }
      for (const [key, w] of shown) {
        if (!want.has(key)) crowd.send(key, GONE, w.state === 'seat' ? 'left' : w.state, undefined, now || undefined);
      }
      shown = want;

      // parties that looked at the line and walked past never entered the queue
      for (const g of sim.ghosts) {
        if (ghosts.has(g)) continue;
        ghosts.add(g);
        if (g.where !== 'door' || now) continue;
        const key = -++balked;
        crowd.send(key, DOOR_LINE[2], 'left', undefined, true);
        crowd.send(key, GONE, 'left');
      }
      return hidden;
    },
    seatParties: () => partyOf,
  };
}
