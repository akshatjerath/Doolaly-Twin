import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import type { Crowd, State } from './sync';
import { advance, GONE, route, SPEED, type Path, type Point } from './walk';

type ToWorld = (px: number) => number;
type Person = {
  at: Point; path: Path; prev: Path; todo: Path; state: State; seat?: [number, number];
  sit: number; face: number; stride: number; walking: number;
};

const MAX = 160;
const SHIRTS = ['#44586b', '#7a5a4c', '#4f6b5c', '#6a5a74', '#8a7a58', '#3f6672', '#8b8f93', '#5b3f45'];
const TROUSERS = ['#2f3a46', '#4a4640', '#33414f', '#5a5248'];
const SKINS = ['#e3b998', '#c4926b', '#a06f4c', '#7b5137'];
const HAIRS = ['#1d1814', '#3b2a1f', '#5a4432', '#7d7873'];

// Ring shape differs too, so state does not rest on colour alone.
const arc = (inner: number, outer: number, start = 0, length = Math.PI * 2) => new THREE.RingGeometry(inner, outer, 32, 1, start, length);
const RINGS: Record<State, [string, THREE.BufferGeometry]> = {
  seat: ['#d98e04', arc(0.28, 0.43)], // thick
  takeaway: ['#2457c5', mergeGeometries([arc(0.26, 0.31), arc(0.37, 0.43)])], // double
  seated: ['#4f5a63', arc(0.36, 0.42)], // thin
  left: ['#c0261b', mergeGeometries([0, 1, 2, 3, 4, 5].map((i) => arc(0.28, 0.43, (i * Math.PI) / 3, Math.PI / 5)))], // dashed
};

/** A limb that hangs down from its joint at the origin. */
const limb = (top: number, bottom: number, length: number) => {
  const parts = [
    new THREE.CylinderGeometry(top, bottom, length, 10).translate(0, -length / 2, 0),
    new THREE.SphereGeometry(top, 10, 8),
    new THREE.SphereGeometry(bottom, 10, 8).translate(0, -length, 0),
  ];
  return mergeGeometries(parts);
};

export function createPeople(parent: THREE.Object3D, wx: ToWorld, wz: ToWorld, instant: boolean) {
  const people = new Map<number, Person>();
  const instanced = (geometry: THREE.BufferGeometry, perPerson = 1, material: THREE.Material = new THREE.MeshStandardMaterial({ roughness: 0.85 })) => {
    const mesh = new THREE.InstancedMesh(geometry, material, MAX * perPerson);
    mesh.castShadow = true;
    mesh.frustumCulled = false; // instances move; the first bounds would go stale
    mesh.count = 0;
    parent.add(mesh);
    return mesh;
  };
  // adult proportions, about 1.7 m: hip 0.9, shoulder 1.43, top of head 1.71
  const torsoShape = [[0.001, 0], [0.13, 0.01], [0.14, 0.1], [0.125, 0.22], [0.16, 0.4], [0.18, 0.5], [0.15, 0.57], [0.055, 0.61], [0.001, 0.62]];
  const torso = instanced(new THREE.LatheGeometry(torsoShape.map(([r, y]) => new THREE.Vector2(r, y)), 16).scale(1, 1, 0.68));
  const neck = instanced(new THREE.CylinderGeometry(0.045, 0.05, 0.09, 10));
  const head = instanced(new THREE.SphereGeometry(0.105, 18, 14).scale(0.92, 1.12, 0.98));
  const hair = instanced(new THREE.SphereGeometry(0.112, 18, 12, 0, Math.PI * 2, 0, Math.PI * 0.55).scale(0.94, 1.12, 1.02).rotateX(-0.35));
  const thighs = instanced(limb(0.075, 0.055, 0.42), 2);
  const shins = instanced(limb(0.055, 0.038, 0.42), 2);
  const shoes = instanced(new THREE.BoxGeometry(0.095, 0.06, 0.22).translate(0, 0, 0.05), 2);
  const upper = instanced(limb(0.047, 0.037, 0.28), 2);
  const fore = instanced(limb(0.036, 0.027, 0.26), 2);
  const hands = instanced(new THREE.SphereGeometry(0.032, 8, 6).scale(1, 1.4, 0.7), 2);
  const rings = Object.fromEntries(Object.entries(RINGS).map(([state, [color, geometry]]) => {
    const mesh = instanced(geometry.rotateX(-Math.PI / 2), 1, new THREE.MeshBasicMaterial({ color }));
    mesh.castShadow = false;
    return [state, mesh];
  })) as Record<State, THREE.InstancedMesh>;
  const meshes = [torso, neck, head, hair, thighs, shins, shoes, upper, fore, hands, ...Object.values(rings)];

  const base = new THREE.Matrix4();
  const local = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  const e = new THREE.Euler();
  const one = new THREE.Vector3(1, 1, 1);
  const pos = new THREE.Vector3();
  const color = new THREE.Color();
  /** Place one part in the person's own frame, tilted by `pitch` about the left-right axis. */
  const part = (mesh: THREE.InstancedMesh, x: number, y: number, z: number, pitch: number, tint?: string) => {
    local.compose(pos.set(x, y, z), q.setFromEuler(e.set(pitch, 0, 0)), one).premultiply(base);
    mesh.setMatrixAt(mesh.count, local);
    if (tint) mesh.setColorAt(mesh.count, color.set(tint));
    mesh.count++;
  };
  /** End of a limb of `length` that starts at (y, z) and hangs at `pitch`. */
  const end = (y: number, z: number, pitch: number, length: number) => [y - Math.cos(pitch) * length, z - Math.sin(pitch) * length];

  const crowd: Crowd = {
    send(id, path, state, seat, now = instant) {
      const p: Person = people.get(id) ?? { at: [...GONE[0]] as Point, path: GONE, prev: GONE, todo: [], state, sit: 0, face: 0, stride: 0, walking: 0 };
      // finish the current leg first, so a change of mind never cuts through a wall
      const heading = p.todo[0];
      if (heading) {
        const onPath = p.path.includes(heading) ? p.path : p.prev;
        p.todo = [heading, ...route(onPath.slice(0, onPath.indexOf(heading) + 1), path)];
        p.prev = onPath;
      } else {
        p.todo = route(p.path, path);
        p.prev = p.path;
      }
      Object.assign(p, { path, state, seat });
      if (now) {
        advance(p.at, p.todo, Infinity);
        p.sit = Number(seat !== undefined);
        if (seat) p.face = seat[0];
      }
      people.set(id, p);
    },
    clear: () => people.clear(),
  };

  return {
    ...crowd,
    /** dt is walking time in seconds; 0 freezes everyone. */
    update(dt: number) {
      for (const mesh of meshes) mesh.count = 0;
      for (const [id, p] of people) {
        const [x, y] = p.at;
        advance(p.at, p.todo, SPEED * dt);
        const moved = Math.hypot(p.at[0] - x, p.at[1] - y);
        if (!p.todo.length && p.path === GONE) {
          people.delete(id);
          continue;
        }
        if (torso.count >= MAX) continue;
        const sitting = !p.todo.length && p.seat !== undefined;
        p.sit = instant ? Number(sitting) : THREE.MathUtils.clamp(p.sit + (sitting ? dt : -dt) / 0.5, 0, 1);
        p.walking = THREE.MathUtils.clamp(p.walking + (moved > 0 ? dt : -dt) / 0.2, 0, 1);
        p.stride += moved * 0.045;
        if (sitting) p.face = p.seat![0];
        else if (moved > 0) p.face = Math.atan2(p.at[0] - x, p.at[1] - y);

        const n = Math.abs(id);
        const shirt = SHIRTS[n % SHIRTS.length];
        const trousers = TROUSERS[(n >> 1) % TROUSERS.length];
        const skin = SKINS[(n >> 2) % SKINS.length];
        const s = p.sit * p.sit * (3 - 2 * p.sit);
        const hip = THREE.MathUtils.lerp(0.9, (p.seat?.[1] ?? 0.45) + 0.08, s);
        const scale = 0.94 + (n % 7) * 0.017;
        base.compose(pos.set(wx(p.at[0]), 0, wz(p.at[1])), q.setFromAxisAngle(THREE.Object3D.DEFAULT_UP, p.face), new THREE.Vector3(scale, 1, scale));

        part(torso, 0, hip - 0.04, 0, s * -0.04, shirt);
        part(neck, 0, hip + 0.59, 0, 0, skin);
        part(head, 0, hip + 0.7, 0.01, 0, skin);
        part(hair, 0, hip + 0.715, 0.005, 0, HAIRS[(n >> 3) % HAIRS.length]);
        for (const side of [-1, 1]) {
          const swing = Math.sin(p.stride + (side > 0 ? Math.PI : 0)) * p.walking * (1 - s);
          // negative pitch swings a hanging limb forward
          const thigh = -swing * 0.45 - s * (Math.PI / 2);
          const knee = thigh + Math.max(0, swing) * 0.5 + s * (Math.PI / 2);
          part(thighs, side * 0.085, hip, 0, thigh, trousers);
          const [ky, kz] = end(hip, 0, thigh, 0.42);
          part(shins, side * 0.085, ky, kz, knee, trousers);
          const [fy, fz] = end(ky, kz, knee, 0.42);
          part(shoes, side * 0.085, Math.max(0.03, fy), fz, 0, '#25282c');
          const arm = swing * 0.35 - s * 0.35;
          const elbow = arm - 0.15 - s * 0.9;
          part(upper, side * 0.2, hip + 0.49, 0, arm, shirt);
          const [ey, ez] = end(hip + 0.49, 0, arm, 0.28);
          part(fore, side * 0.205, ey, ez, elbow, skin);
          const [hy, hz] = end(ey, ez, elbow, 0.29);
          part(hands, side * 0.205, hy, hz, elbow, skin);
        }
        // waiting rings are drawn larger so they read from across the room
        base.scale(pos.setScalar(p.state === 'seated' ? 1 : 1.2));
        part(rings[p.state], 0, 0.012, 0, 0);
      }
      for (const mesh of meshes) {
        mesh.instanceMatrix.needsUpdate = true;
        if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
      }
    },
  };
}
