// Traced by eye from "Floor plan.png" shown 1652 px wide. Numbers are image pixels so they can be checked against it.
// The drawing's own dimension labels contradict each other, so the scale is assumed (door and chair size).
export const M_PER_PX = 0.009;
export const BOUNDS = { x0: 200, y0: 243, x1: 1468, y1: 1757, patioY: 2010 };

export type Mat = 'wall' | 'oak' | 'dark' | 'steel' | 'seat' | 'glass';
/** [x0, y0, x1, y1, height m, material, base m] */
export type Block = [number, number, number, number, number, Mat, number?];

const FAR = 2.2; // back and left walls
const LOW = 1.1; // cutaway: near walls

export const WALLS: Block[] = [
  [200, 243, 1150, 270, FAR, 'wall'], [1236, 243, 1468, 270, FAR, 'wall'],
  [200, 270, 227, 1731, FAR, 'wall'],
  // right side, with three windows
  [1440, 270, 1468, 790, LOW, 'wall'], [1440, 960, 1468, 988, LOW, 'wall'], [1440, 1157, 1468, 1186, LOW, 'wall'], [1440, 1357, 1468, 1731, LOW, 'wall'],
  [1440, 790, 1468, 960, 0.75, 'wall'], [1440, 988, 1468, 1157, 0.75, 'wall'], [1440, 1186, 1468, 1357, 0.75, 'wall'],
  [1450, 790, 1456, 960, 0.9, 'glass', 0.75], [1450, 988, 1456, 1157, 0.9, 'glass', 0.75], [1450, 1186, 1456, 1357, 0.9, 'glass', 0.75],
  // glass storefront on the street side, door gap at 737..948
  [200, 1731, 376, 1757, LOW, 'wall'], [674, 1731, 737, 1757, LOW, 'wall'], [948, 1731, 1012, 1757, LOW, 'wall'], [1309, 1731, 1468, 1757, LOW, 'wall'],
  [376, 1741, 674, 1747, 2.0, 'glass'], [1012, 1741, 1309, 1747, 2.0, 'glass'],
  [731, 1731, 743, 1757, 2.1, 'dark'], [942, 1731, 954, 1757, 2.1, 'dark'],
  // store room, kitchen, restrooms
  [423, 270, 436, 380, FAR, 'wall'], [423, 461, 436, 565, FAR, 'wall'], [227, 565, 527, 583, LOW, 'wall'], [514, 583, 527, 660, LOW, 'wall'],
  [1126, 270, 1140, 565, LOW, 'wall'], [1053, 565, 1140, 620, LOW, 'wall'],
  [1254, 270, 1269, 350, LOW, 'wall'], [1140, 498, 1154, 512, LOW, 'wall'], [1238, 498, 1440, 512, LOW, 'wall'],
  [1254, 600, 1269, 755, LOW, 'wall'], [1254, 742, 1440, 756, LOW, 'wall'],
  // side alcove
  [1158, 1391, 1440, 1405, LOW, 'wall'], [1158, 1405, 1172, 1497, LOW, 'wall'], [1158, 1710, 1172, 1731, LOW, 'wall'],
];

// storefront frame, so the glass reads
for (const [from, to] of [[376, 674], [1012, 1309]]) {
  WALLS.push([from, 1738, to, 1750, 0.07, 'dark', 2.0]);
  for (let i = 0; i <= 3; i++) {
    const x = from + ((to - from - 8) * i) / 3;
    WALLS.push([x, 1738, x + 8, 1750, 2.0, 'dark']);
  }
}

/** [x, y, facing in radians (0 = toward the street), seat height m] */
export type Seat = [number, number, number, number];
const E = Math.PI / 2;
const ROWS = [860, 1000, 1075, 1215, 1290, 1430];

/** Chairs with their own mesh. */
export const CHAIRS: Seat[] = [
  ...ROWS.map((y): Seat => [668, y, E, 0.45]),
  ...ROWS.map((y): Seat => [1048, y, -E, 0.45]),
  ...[790, 912, 1015, 1135, 1245].map((y, i): Seat => [1334, y, i % 2 ? Math.PI : 0, 0.45]),
];
export const STOOLS: Seat[] = [350, 438, 527, 617].map((x): Seat => [x, 1648, 0, 0.75]);
/** Places on built-in benches (banquette and alcove). */
const BENCH: Seat[] = [
  ...ROWS.map((y): Seat => [805, y, -E, 0.45]),
  ...ROWS.map((y): Seat => [910, y, E, 0.45]),
  [1305, 1448, 0, 0.45], [1390, 1465, -E, 0.45], [1390, 1535, -E, 0.45],
  [1390, 1605, -E, 0.45], [1360, 1680, Math.PI, 0.45], [1250, 1680, Math.PI, 0.45],
];
/** Every indoor seat the twin can fill. Patio is drawn but not counted. */
export const SEATS: Seat[] = [...CHAIRS, ...STOOLS, ...BENCH];

/** Table tops: [x0, y0, x1, y1] */
export const TABLES: [number, number, number, number][] = [
  ...ROWS.flatMap((y): [number, number, number, number][] => [[688, y - 36, 760, y + 36], [955, y - 36, 1027, y + 36]]),
  [1293, 815, 1375, 890], [1293, 1040, 1375, 1115], [1293, 1265, 1375, 1340],
];
export const PATIO_TABLES: [number, number][] = [[343, 1872], [570, 1872], [1100, 1872], [1327, 1872]];

export const FIXTURES: Block[] = [
  // kitchen
  [436, 270, 1126, 350, 0.9, 'steel'], [1040, 350, 1126, 500, 0.9, 'steel'], [645, 500, 1126, 565, 0.95, 'steel'], [645, 565, 1053, 608, 1.1, 'oak'],
  [227, 285, 303, 475, 0.9, 'steel'], [232, 480, 310, 558, 0.9, 'steel'], [443, 490, 515, 565, 0.9, 'steel'],
  // coffee and pastry bar
  [227, 583, 306, 1485, 0.9, 'dark'], [306, 583, 514, 660, 0.9, 'dark'], [227, 1403, 427, 1485, 0.9, 'dark'],
  [427, 775, 527, 835, 1.05, 'oak'], [427, 835, 527, 1017, 0.9, 'dark'], [432, 840, 522, 1012, 0.4, 'glass', 0.9],
  [427, 1017, 527, 1310, 0.95, 'dark'], [427, 1310, 527, 1485, 1.05, 'oak'],
  // front bar and window ledge
  [227, 1486, 306, 1731, 1.05, 'oak'], [306, 1672, 677, 1731, 1.05, 'oak'], [1377, 755, 1437, 1391, 0.75, 'oak'],
  // central banquette, two sides
  [775, 805, 835, 1485, 0.45, 'seat'], [835, 805, 847, 1485, 0.95, 'seat'], [868, 805, 880, 1485, 0.95, 'seat'], [880, 805, 940, 1485, 0.45, 'seat'],
  [775, 775, 940, 805, 0.95, 'oak'], [775, 1485, 940, 1515, 0.95, 'oak'],
  // alcove bench (U shape)
  [1268, 1410, 1425, 1485, 0.45, 'seat'], [1355, 1485, 1425, 1645, 0.45, 'seat'], [1190, 1645, 1425, 1715, 0.45, 'seat'],
  // patio posts and rail
  ...[200, 672, 989, 1448].map((x): Block => [x, 1982, x + 20, 2002, 0.95, 'dark']),
  [236, 1988, 666, 1996, 0.06, 'dark', 0.85], [1019, 1988, 1430, 1996, 0.06, 'dark', 0.85],
];
