import toast from '../data/angry-toast.json';
import boojee from '../data/boojee.json';
import { createViews } from './scene';
import { DT, Sim, type Config, type Scenario } from './sim';
import { createSync } from './sync';
import './style.css';

type Shop = typeof boojee;
type Params = Shop['assumed'];
const SHOPS: Shop[] = [boojee, toast];

const $ = <T extends HTMLElement = HTMLElement>(id: string) => document.getElementById(id) as T;
const el = (tag: string, text = '', className = '') => {
  const node = document.createElement(tag);
  node.textContent = text;
  if (className) node.className = className;
  return node;
};

const SLIDERS: { k: keyof Params; label: string; min: number; max: number; step: number; unit: string; group: 'shop' | 'people' }[] = [
  { k: 'peak', label: 'Groups arriving per hour at the busiest time', min: 0, max: 80, step: 1, unit: '', group: 'shop' },
  { k: 'seats', label: 'Seats', min: 0, max: 39, step: 1, unit: '', group: 'shop' },
  { k: 'dwell', label: 'Time a group stays seated', min: 10, max: 90, step: 5, unit: ' min', group: 'shop' },
  { k: 'take', label: 'Share of groups taking away', min: 0, max: 90, step: 5, unit: '%', group: 'shop' },
  { k: 'order', label: 'Time to order at the counter', min: 0.5, max: 4, step: 0.5, unit: ' min', group: 'shop' },
  { k: 'tills', label: 'People taking orders', min: 1, max: 3, step: 1, unit: '', group: 'shop' },
  { k: 'prep', label: 'Time from order to ready', min: 2, max: 20, step: 1, unit: ' min', group: 'shop' },
  { k: 'patience', label: 'How long a group waits before leaving', min: 5, max: 60, step: 5, unit: ' min', group: 'people' },
  { k: 'balk', label: 'Chance of walking past, per group already in line', min: 0, max: 8, step: 1, unit: '%', group: 'people' },
  { k: 'boost', label: 'Patience when waiting by phone, against in line', min: 100, max: 200, step: 5, unit: '%', group: 'people' },
];

const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
let views: ReturnType<typeof createViews>;
try {
  views = createViews([$('viewA'), $('viewB')], reduceMotion);
} catch (error) {
  $('viewA').textContent = 'This browser cannot show 3D (WebGL is off or unavailable).';
  throw error;
}
const syncs = views.people.map(createSync);

let shop = SHOPS[0];
let hour = shop.defaultHour - shop.openHour;
let params: Params = { ...shop.assumed };
let seed = 7;
let running = !reduceMotion;
let speed = 1;
let acc = 0;
let sims: Sim[] = [];

const scenarios = (): Scenario[] => [
  { waitlist: false, shelf: false },
  { waitlist: $<HTMLInputElement>('tWait').checked, shelf: $<HTMLInputElement>('tShelf').checked },
];
const config = (): Config => ({
  lambda: (shop.saturdayBusyness[hour] / 100) * params.peak,
  seats: params.seats, dwell: params.dwell, take: params.take / 100, order: params.order, tills: params.tills,
  prep: params.prep, patience: params.patience, balk: params.balk / 100, boost: params.boost / 100,
});
const hourLabel = (h: number) => `${h % 12 || 12} ${h % 24 < 12 ? 'am' : 'pm'}`;

/** Place everyone where the simulation has them, without walking there. */
function snap() {
  sims.forEach((sim, i) => {
    syncs[i].reset();
    syncs[i].update(sim, true);
  });
  numbers();
}
function reset() {
  sims = scenarios().map((scen) => new Sim(config(), scen, seed));
  for (const sim of sims) {
    for (let i = 0; i < 120; i++) sim.step(); // 30 simulated minutes of warm-up
    sim.resetStats();
  }
  acc = 0;
  snap();
}

const f1 = (v: number) => v.toFixed(1);
const f0 = (v: number) => String(Math.round(v));
function numbers() {
  const [a, b] = sims.map((s) => s.summary());
  const early = a.minutes < 5;
  [a, b].forEach((s, i) => {
    const quote = !sims[i].scen.waitlist ? 'None' : sims[i].cfg.seats ? `${s.quoteNow} min` : 'No seats';
    const cells: [string, string][] = [
      ['Groups waiting for a seat', String(s.queueNow)],
      ['Walked away, per hour', early ? '…' : f1(s.walkPerHr)],
      ['Average wait for a seat', `${f1(s.avgWait)} min`],
      ['Seats in use', `${f0(s.util * 100)}%`],
      ['Standing among tables', f1(s.among)],
      ['Wait quoted now', quote],
    ];
    $(i ? 'mB' : 'mA').replaceChildren(...cells.map(([label, value]) => {
      const cell = el('div');
      cell.append(el('b', value), el('span', label));
      return cell;
    }));
  });

  const rows: [string, number, number, (v: number) => string, boolean][] = [
    ['Walked away, per hour', a.walkPerHr, b.walkPerHr, f1, true],
    ['Average wait for a seat (min)', a.avgWait, b.avgWait, f1, true],
    ['Slowest 1 in 10 waits (min)', a.p90, b.p90, f1, true],
    ['Seats in use (%)', a.util * 100, b.util * 100, f0, false],
    ['People standing among tables, average', a.among, b.among, f1, true],
    ['Average time to get a takeaway (min)', a.takeAvg, b.takeAvg, f1, true],
  ];
  const tr = (texts: string[], mark = '') => {
    const row = el('tr');
    texts.forEach((text, i) => row.append(el(i ? 'td' : 'th', text, i === 3 ? mark : '')));
    return row;
  };
  const body = rows.map(([label, x, y, format, lowerIsBetter]) => {
    const d = y - x;
    const verdict = !lowerIsBetter || Math.abs(d) < 0.05 ? '' : d < 0 ? 'better' : 'worse';
    const change = Math.abs(d) < 0.05 ? 'same' : `${d > 0 ? '+' : ''}${format(d)}${verdict ? `, ${verdict}` : ''}`;
    return a.minutes < 30 ? tr([label, '…', '…', '…']) : tr([label, format(x), format(y), change], verdict);
  });
  if (b.quoteErr != null && a.minutes >= 30)body.push(tr(['Quoted wait off by (min, average)', 'No quote', f1(b.quoteErr), '']));
  $('cmp').replaceChildren(...body);

  const when = `${shop.label}, Saturday around ${hourLabel(shop.openHour + hour)}`;
  const quiet = a.walk + b.walk === 0 && a.p90 === 0 && b.p90 === 0;
  $('pitch').textContent = a.minutes < 30
    ? 'Counting. Let it run for half a simulated hour, or press "Run 2 hours".'
    : quiet
      ? `${when}: with these guessed numbers, hardly anyone has to wait for a seat, so the waitlist changes little. The shelf still changes where takeaway customers stand.`
      : `${when}: with these guessed numbers, ${f1(a.walkPerHr)} groups an hour walk away today and ${f1(b.walkPerHr)} with the changes. The average wait for a seat goes from ${f1(a.avgWait)} to ${f1(b.avgWait)} minutes. This is not a result until the guesses are counted on site.`;
  const mins = Math.floor(a.minutes);
  $('clock').textContent = `Counted so far: ${Math.floor(mins / 60)} h ${mins % 60} min`;
}

function buildData() {
  $('title').textContent = `${shop.label}: waiting zone`;
  $('status').textContent = `Snapshot, not live: "${shop.statusSnapshot.text}" on ${shop.statusSnapshot.takenAt}`;
  $('facts').replaceChildren(...shop.facts.map((f) => el('li', f)));
  $('source').textContent = `Source: ${shop.source}. Retrieved ${shop.retrievedOn}. ${shop.busynessNote}`;
  $('roomNote').textContent = shop === boojee
    ? 'Room: traced by eye from a supplied floor plan, scale guessed, not measured.'
    : 'Room shown is Boojee Cafe\'s layout, reused. It is not Angry Toast\'s room.';
  $('seatsNote').textContent = shop.seatsNote;
  $('bars').replaceChildren(...shop.saturdayBusyness.map((v, i) => {
    const h = shop.openHour + i;
    const bar = el('button', '', 'bar') as HTMLButtonElement;
    bar.type = 'button';
    bar.setAttribute('aria-label', `${hourLabel(h)}, ${v}% of the weekly peak`);
    bar.setAttribute('aria-pressed', String(i === hour));
    const fill = el('span', '', 'fill');
    fill.style.height = `${v}%`;
    bar.append(fill, el('small', i % 3 ? '' : hourLabel(h).replace(' ', '')));
    bar.onclick = () => {
      hour = i;
      buildData();
      ($('bars').children[i] as HTMLElement).focus();
      reset();
    };
    return bar;
  }));
  $('hourNote').textContent = `Showing Saturday ${hourLabel(shop.openHour + hour)}: about ${shop.saturdayBusyness[hour]}% of the weekly peak`;
}

let pending: number | undefined;
function buildSliders() {
  const groups = { shop: $('grpShop'), people: $('grpPeople') };
  for (const g of Object.values(groups)) g.replaceChildren();
  for (const d of SLIDERS) {
    const wrap = el('div', '', 'slider');
    const label = el('label');
    const name = el('span', d.label);
    name.append(el('em', 'Assumed', 'tag'));
    const out = el('output', `${params[d.k]}${d.unit}`);
    label.append(name, out);
    label.setAttribute('for', `s_${d.k}`);
    const input = Object.assign(document.createElement('input'), { type: 'range', id: `s_${d.k}`, min: String(d.min), max: String(d.max), step: String(d.step), value: String(params[d.k]) });
    input.oninput = () => {
      params[d.k] = Number(input.value);
      out.textContent = `${input.value}${d.unit}`;
      clearTimeout(pending);
      pending = window.setTimeout(reset, 150);
    };
    wrap.append(label, input);
    groups[d.group].append(wrap);
  }
}

$('shop').replaceChildren(...SHOPS.map((s, i) => new Option(`${s.label}, ${s.place}`, String(i))));
$<HTMLSelectElement>('shop').onchange = (e) => {
  shop = SHOPS[Number((e.target as HTMLSelectElement).value)];
  hour = shop.defaultHour - shop.openHour;
  params = { ...shop.assumed };
  buildData();
  buildSliders();
  reset();
};
const play = $<HTMLButtonElement>('play');
const showPlay = () => { play.textContent = running ? 'Pause' : 'Play'; };
play.onclick = () => { running = !running; showPlay(); };
$('restart').onclick = reset;
$('newday').onclick = () => { seed = (seed * 31 + 11) % 100000; reset(); };
$('ff').onclick = () => {
  for (let i = 0; i < 120 / DT; i++) sims.forEach((s) => s.step());
  snap();
};
$('busy').onclick = () => {
  params.peak = 40;
  buildSliders();
  reset();
  $('ff').click();
};
$<HTMLSelectElement>('speed').onchange = (e) => { speed = Number((e.target as HTMLSelectElement).value); };
$('tWait').onchange = reset;
$('tShelf').onchange = reset;

buildData();
buildSliders();
showPlay();
reset();

let last = performance.now();
let lastNumbers = 0;
function frame(now: number) {
  const dt = Math.max(0, Math.min((now - last) / 1000, 0.1)); // no jump after a hidden tab
  last = now;
  if (running) {
    acc += dt * speed;
    let n = Math.floor(acc / DT);
    acc -= n * DT;
    while (n-- > 0) sims.forEach((s) => s.step());
    sims.forEach((s, i) => syncs[i].update(s));
    if (now - lastNumbers > 250) {
      lastNumbers = now;
      numbers();
    }
  }
  // 1.2 m/s at the default speed; faster only when the clock runs faster, so people keep up
  const walking = running ? dt * Math.max(1, speed) : 0;
  views.people.forEach((p) => p.update(walking));
  views.render(sims.map((s) => ({ ...s.scen, line: s.dineQ.length > 0, takeaway: s.prep.length > 0 })), now / 1000);
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
