import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { CHAIRS, M_PER_PX, PATIO_TABLES, STOOLS, TABLES, type Seat } from './plan';

type ToWorld = (px: number) => number;

const std = (color: string, roughness = 0.8) => new THREE.MeshStandardMaterial({ color, roughness });
const LEATHER = std('#8a5a45', 0.6);
const PATIO = std('#8d8f8c');
const TOP = std('#f1f2f0', 0.5);
const OAK = std('#b79b7a', 0.6);
const METAL = std('#4d555b', 0.4);
const LEAF = std('#6f8571', 1);
const CAR = std('#7d909b', 0.35);
const ACCENT = std('#0b7a6b', 0.7); // marks what the two changes add

const box = (w: number, h: number, d: number, x = 0, y = 0, z = 0) =>
  new RoundedBoxGeometry(w, h, d, 2, Math.min(w, h, d) / 4).translate(x, y, z);

/** Seat, four legs and a back that sits behind a sitter facing +z. */
function chairGeometry(seat: number, back: boolean) {
  const parts = [box(0.44, 0.06, 0.42, 0, seat - 0.03, 0)];
  for (const x of [-0.17, 0.17]) for (const z of [-0.16, 0.16]) parts.push(box(0.04, seat - 0.05, 0.04, x, (seat - 0.05) / 2, z));
  if (back) parts.push(box(0.44, 0.34, 0.05, 0, seat + 0.24, -0.2), box(0.04, 0.12, 0.04, -0.17, seat + 0.05, -0.2), box(0.04, 0.12, 0.04, 0.17, seat + 0.05, -0.2));
  return mergeGeometries(parts);
}

export function addFurniture(scene: THREE.Object3D,wx: ToWorld, wz: ToWorld) {
  const m = (px: number) => px * M_PER_PX;
  const add = (geometry: THREE.BufferGeometry, material: THREE.Material, parent: THREE.Object3D = scene) => {
    const mesh = new THREE.Mesh(geometry, material);
    mesh.castShadow = mesh.receiveShadow = true;
    parent.add(mesh);
    return mesh;
  };
  const instances = (geometry: THREE.BufferGeometry, material: THREE.Material, seats: Seat[]) => {
    const mesh = new THREE.InstancedMesh(geometry, material, seats.length);
    const o = new THREE.Object3D();
    seats.forEach(([x, y, angle], i) => {
      o.position.set(wx(x), 0, wz(y));
      o.rotation.y = angle;
      o.updateMatrix();
      mesh.setMatrixAt(i, o.matrix);
    });
    mesh.castShadow = mesh.receiveShadow = true;
    scene.add(mesh);
  };
  const table = (x: number, y: number, w: number, d: number, top: THREE.Material, turn = 0) => {
    const g = mergeGeometries([box(w, 0.04, d, 0, 0.74), box(0.07, 0.72, 0.07, 0, 0.36), box(0.36, 0.03, 0.36, 0, 0.015)]);
    const mesh = add(g, top);
    mesh.position.set(wx(x), 0, wz(y));
    mesh.rotation.y = turn;
  };

  instances(chairGeometry(0.45, true), LEATHER, CHAIRS);
  instances(chairGeometry(0.75, true), LEATHER, STOOLS);
  for (const [x0, y0, x1, y1] of TABLES) table((x0 + x1) / 2, (y0 + y1) / 2, m(x1 - x0), m(y1 - y0) - 0.03, x0 > 1200 ? OAK : TOP);

  const patioChairs: Seat[] = [];
  for (const [x, y] of PATIO_TABLES) {
    table(x, y, 0.72, 0.72, OAK, Math.PI / 4);
    for (const dx of [-58, 58]) for (const dy of [-58, 58]) patioChairs.push([x + dx, y + dy, Math.atan2(-dx, -dy), 0.45]);
  }
  instances(chairGeometry(0.45, true), PATIO, patioChairs);

  // espresso machine, grinder, till screen
  for (const [x, y, w, h, d, base] of [[477, 1160, 0.45, 0.42, 0.95, 0.95], [475, 1255, 0.22, 0.38, 0.22, 0.95], [372, 1445, 0.45, 0.28, 0.08, 0.9]]) {
    add(box(w, h, d, wx(x), base + h / 2, wz(y)), METAL);
  }

  const planter = (x: number, y: number) => {
    add(box(0.4, 0.35, 0.4, wx(x), 0.175, wz(y)), METAL);
    add(new THREE.IcosahedronGeometry(0.3, 1).translate(wx(x), 0.58, wz(y)), LEAF);
  };
  [[248, 1790], [1420, 1790], [700, 1790], [985, 1790]].forEach(([x, y]) => planter(x, y));

  // What "With changes" adds: pickup shelf with ready board, and a place to wait away from the door.
  // returned unattached: the caller adds them and shows each only where its change is on
  const shelf = new THREE.Group();
  const wait = new THREE.Group();
  for (const h of [0.55, 0.95, 1.35]) add(box(m(130), 0.05, 0.34, wx(375), h, wz(1510)), ACCENT, shelf);
  for (const x of [312, 438]) add(box(0.05, 1.4, 0.34, wx(x), 0.7, wz(1510)), ACCENT, shelf);
  add(box(m(130), 0.32, 0.05, wx(375), 1.65, wz(1495)), METAL, shelf);
  add(box(m(260), 0.015, m(420), wx(80), -0.11, wz(1980)), std('#8fbdb4', 1), wait);
  add(mergeGeometries([box(0.42, 0.08, 2.6, wx(-30), 0.45, wz(1980)), box(0.3, 0.42, 0.08, wx(-30), 0.21, wz(1850)), box(0.3, 0.42, 0.08, wx(-30), 0.21, wz(2110))]), OAK, wait);
  for (const y of [1740, 2220]) {
    add(box(0.4, 0.35, 0.4, wx(20), 0.175, wz(y)), METAL, wait);
    add(new THREE.IcosahedronGeometry(0.3, 1).translate(wx(20), 0.58, wz(y)), LEAF, wait);
  }

  // one muted car that passes now and then
  const car = new THREE.Group();
  add(box(2.6, 0.5, 1.2, 0, 0.45), CAR, car);
  add(box(1.4, 0.42, 1.1, -0.1, 0.9), CAR, car);
  for (const x of [-0.85, 0.85]) for (const z of [-0.56, 0.56]) add(new THREE.CylinderGeometry(0.26, 0.26, 0.16, 16).rotateX(Math.PI / 2).translate(x, 0.2, z), METAL, car);
  car.position.set(wx(1150), -0.09, wz(2240));
  scene.parent!.add(car); // moves, so it stays out of the merged still geometry

  /** t in seconds. Crosses the plot, then stays away for a while. */
  const drive = (t: number) => {
    const x = wx(-20) + 1.4 + (t % 14) * 2.4;
    car.visible = x < wx(1688) - 1.4;
    car.position.x = x;
  };
  return { shelf, wait, drive };
}
