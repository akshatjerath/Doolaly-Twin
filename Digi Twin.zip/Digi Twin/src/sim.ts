// Port of reference-twin.html between SIM-START and SIM-END. Behaviour is identical for 2 or more seats
// (test/sim.test.ts compares them). The only additions guard 0 and 1 seat. No Three.js here.

export type Config = {
  lambda: number; seats: number; dwell: number; take: number; order: number; tills: number;
  prep: number; patience: number; balk: number; boost: number;
};
export type Scenario = { waitlist: boolean; shelf: boolean };
export type Party = {
  id: number; size: number; take: boolean; arr: number;
  pU: number; bU: number; dU: number; oU: number; rU: number;
  quote: number | null; patience: number; readyAt: number; leaveT: number;
};
export type Ghost = { age: number; where: 'door' | 'queue' };

export function rng32(a: number) {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export const DT = 0.25;

export class Sim {
  rand: () => number;
  t = 0;
  nextId = 1;
  dineQ: Party[] = [];
  seated: Party[] = [];
  tillQ: Party[] = [];
  prep: Party[] = [];
  ghosts: Ghost[] = [];
  tills: { p: Party | null; end: number }[] = [];
  seatsUsed = 0;
  nextArr: number;
  st!: {
    t0: number; arrDine: number; arrTake: number; seatedN: number; balk: number; renege: number;
    waits: number[]; quoteErr: number[]; util: number; among: number; shelf: number; takeDone: number; takeTime: number;
  };

  constructor(public cfg: Config, public scen: Scenario, seed: number) {
    this.rand = rng32(seed);
    for (let i = 0; i < cfg.tills; i++) this.tills.push({ p: null, end: 0 });
    this.resetStats();
    this.nextArr = this.gap();
  }
  resetStats() {
    this.st = { t0: this.t, arrDine: 0, arrTake: 0, seatedN: 0, balk: 0, renege: 0, waits: [], quoteErr: [], util: 0, among: 0, shelf: 0, takeDone: 0, takeTime: 0 };
  }
  gap() {
    const lam = this.cfg.lambda / 60;
    return lam > 0 ? -Math.log(1 - this.rand()) / lam : 1e9;
  }
  mkParty(): Party {
    const r = this.rand;
    const u = [r(), r(), r(), r(), r(), r(), r()];
    const take = u[1] < this.cfg.take;
    let size = take ? (u[0] < 0.7 ? 1 : 2) : u[0] < 0.25 ? 1 : u[0] < 0.7 ? 2 : u[0] < 0.85 ? 3 : 4;
    size = Math.min(size, Math.max(this.cfg.seats, 1)); // guard: 0 seats must not make empty parties
    return { id: this.nextId++, size, take, arr: this.t, pU: u[2], bU: u[3], dU: u[4], oU: u[5], rU: u[6], quote: null, patience: 0, readyAt: 0, leaveT: 0 };
  }
  /** Minutes until a party of two would fit, walking the queue against seated leave times. */
  quote() {
    if (this.cfg.seats < 1) return 0; // guard: no seats, nothing to quote
    const rel = this.seated.map((p) => ({ t: p.leaveT, n: p.size })).sort((a, b) => a.t - b.t);
    let free = this.cfg.seats - this.seatsUsed;
    let t = this.t;
    const need = this.dineQ.map((p) => p.size).concat([Math.min(2, this.cfg.seats)]); // guard: 1 seat
    for (const n of need) {
      while (free < n && rel.length) {
        const r = rel.shift()!;
        t = Math.max(t, r.t);
        free += r.n;
      }
      if (free < n) {
        t += this.cfg.dwell;
        free = this.cfg.seats;
      }
      free -= n;
      rel.push({ t: t + this.cfg.dwell, n });
      rel.sort((a, b) => a.t - b.t);
    }
    return Math.max(0, Math.round(t - this.t));
  }
  ghost(where: Ghost['where']) {
    this.ghosts.push({ age: 0, where });
    if (this.ghosts.length > 14) this.ghosts.shift();
  }
  arrive(p: Party) {
    const c = this.cfg;
    const s = this.scen;
    if (p.take) {
      this.st.arrTake++;
      this.tillQ.push(p);
      return;
    }
    this.st.arrDine++;
    const vis = s.waitlist ? 0 : this.dineQ.length;
    const bp = Math.min(0.6, c.balk * vis);
    if (p.bU < bp) {
      this.st.balk++;
      this.ghost('door');
      return;
    }
    p.patience = c.patience * (0.5 + p.pU) * (s.waitlist ? c.boost : 1);
    p.quote = s.waitlist ? this.quote() : null;
    this.dineQ.push(p);
  }
  step() {
    const c = this.cfg;
    const s = this.scen;
    this.t += DT;
    while (this.nextArr <= this.t) {
      const p = this.mkParty();
      this.nextArr += this.gap();
      this.arrive(p);
    }
    for (const k of this.tills) {
      if (k.p && k.end <= this.t) {
        k.p.readyAt = this.t + c.prep * (0.6 + 0.8 * k.p.rU);
        this.prep.push(k.p);
        k.p = null;
      }
    }
    for (const k of this.tills) {
      if (!k.p && this.tillQ.length) {
        const p = this.tillQ.shift()!;
        k.p = p;
        k.end = this.t + c.order * (0.6 + 0.8 * p.oU);
      }
    }
    for (let i = this.prep.length - 1; i >= 0; i--) {
      const p = this.prep[i];
      if (p.readyAt <= this.t) {
        this.prep.splice(i, 1);
        if (p.arr >= this.st.t0) {
          this.st.takeDone++;
          this.st.takeTime += this.t - p.arr;
        }
      }
    }
    for (let i = this.seated.length - 1; i >= 0; i--) {
      const p = this.seated[i];
      if (p.leaveT <= this.t) {
        this.seated.splice(i, 1);
        this.seatsUsed -= p.size;
      }
    }
    for (let i = 0; i < this.dineQ.length; i++) {
      const p = this.dineQ[i];
      if (this.t - p.arr > p.patience) {
        this.dineQ.splice(i, 1);
        i--;
        if (p.arr >= this.st.t0) this.st.renege++;
        this.ghost('queue');
      }
    }
    while (this.dineQ.length && c.seats - this.seatsUsed >= this.dineQ[0].size) {
      const p = this.dineQ.shift()!;
      p.leaveT = this.t + c.dwell * (0.6 + 0.8 * p.dU);
      this.seated.push(p);
      this.seatsUsed += p.size;
      if (p.arr >= this.st.t0) {
        const w = this.t - p.arr;
        this.st.waits.push(w);
        this.st.seatedN++;
        if (p.quote != null) this.st.quoteErr.push(Math.abs(w - p.quote));
      }
    }
    const among = this.prep.reduce((a, p) => a + p.size, 0);
    this.st.util += this.seatsUsed * DT;
    this.st.among += (s.shelf ? 0 : among) * DT;
    this.st.shelf += (s.shelf ? among : 0) * DT;
    for (const g of this.ghosts) g.age += DT;
    this.ghosts = this.ghosts.filter((g) => g.age < 3);
  }
  summary() {
    const st = this.st;
    const mins = Math.max(this.t - st.t0, 1e-9);
    const w = st.waits.slice().sort((a, b) => a - b);
    const avg = w.length ? w.reduce((a, b) => a + b, 0) / w.length : 0;
    const p90 = w.length ? w[Math.min(w.length - 1, Math.floor(0.9 * w.length))] : 0;
    const qe = st.quoteErr.length ? st.quoteErr.reduce((a, b) => a + b, 0) / st.quoteErr.length : null;
    return {
      minutes: mins, arrDine: st.arrDine, seated: st.seatedN, balk: st.balk, renege: st.renege,
      walk: st.balk + st.renege, walkPerHr: (st.balk + st.renege) / (mins / 60), seatedPerHr: st.seatedN / (mins / 60),
      avgWait: avg, p90, util: this.cfg.seats ? st.util / (this.cfg.seats * mins) : 0,
      among: st.among / mins, shelf: st.shelf / mins, takeAvg: st.takeDone ? st.takeTime / st.takeDone : 0,
      queueNow: this.dineQ.length, quoteErr: qe, quoteNow: this.quote(),
    };
  }
}
