// One shared 3D room, drawn by two panes through one camera, so turning one turns both.
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { CSS2DObject, CSS2DRenderer } from 'three/examples/jsm/renderers/CSS2DRenderer.js';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { addFurniture } from './furniture';
import { createPeople } from './people';
import { BOUNDS, FIXTURES, M_PER_PX, SEATS, WALLS, type Block, type Mat } from './plan';
import type { Scenario } from './sim';

const m = (px: number) => px * M_PER_PX;
const CX = (BOUNDS.x0 + BOUNDS.x1) / 2;
const CY = (BOUNDS.y0 + BOUNDS.patioY) / 2 + 115; // centre of the whole plot, street included
const wx = (px: number) => m(px - CX);
const wz = (py: number) => m(py - CY);

const std = (color: string, roughness = 0.9) => new THREE.MeshStandardMaterial({ color, roughness });
const MATS: Record<Mat, THREE.Material> = {
  wall: std('#e9ebea'),
  oak: std('#b79b7a', 0.7),
  dark: std('#6a747b', 0.65),
  steel: std('#b9c0c4', 0.45),
  seat: std('#7f8b8c', 1),
  glass: new THREE.MeshStandardMaterial({ color: '#a9c8d2', transparent: true, opacity: 0.22, roughness: 0.1, depthWrite: false }),
};

/** Merge still meshes that share a material: a few draw calls instead of hundreds. */
function merge(root: THREE.Object3D) {
  root.updateMatrixWorld(true);
  const groups = new Map<THREE.Material, THREE.Mesh[]>();
  root.traverse((o) => {
    const mesh = o as THREE.Mesh;
    if (!mesh.isMesh || (mesh as THREE.InstancedMesh).isInstancedMesh) return;
    const material = mesh.material as THREE.Material;
    groups.set(material, [...(groups.get(material) ?? []), mesh]);
  });
  for (const [material, list] of groups) {
    const geometries = list.map((mesh) => (mesh.geometry.index ? mesh.geometry.toNonIndexed() : mesh.geometry.clone()).applyMatrix4(mesh.matrixWorld));
    const merged = new THREE.Mesh(mergeGeometries(geometries), material);
    merged.castShadow = list[0].castShadow;
    merged.receiveShadow = true;
    list.forEach((mesh) => mesh.removeFromParent());
    root.add(merged);
  }
}

function buildRoom() {
  const scene = new THREE.Scene();
  const still = new THREE.Group();
  scene.add(still);
  const block = ([x0, y0, x1, y1, h, mat, base = 0]: Block, material = MATS[mat]) => {
    const w = m(x1 - x0);
    const d = m(y1 - y0);
    const mesh = new THREE.Mesh(new RoundedBoxGeometry(w, h, d, 2, Math.min(0.02, w / 4, d / 4, h / 4)), material);
    mesh.position.set(wx((x0 + x1) / 2), base + h / 2, wz((y0 + y1) / 2));
    mesh.castShadow = mat !== 'glass';
    mesh.receiveShadow = true;
    still.add(mesh);
  };
  const { x0, y0, x1, y1, patioY } = BOUNDS;
  block([x0 - 220, y0 - 100, x1 + 220, patioY + 330, 0.1, 'wall', -0.22], std('#a8b0ac'));
  block([x0 - 220, patioY + 20, x1 + 220, patioY + 130, 0.04, 'wall', -0.12], std('#c9ced0'));
  block([x0 - 220, patioY + 140, x1 + 220, patioY + 320, 0.03, 'wall', -0.12], std('#5d656b'));
  block([x0, y1, x1, patioY, 0.12, 'oak', -0.12], std('#c3b29c'));
  block([x0, y0, x1, y1, 0.12, 'wall', -0.12], std('#c8cbca', 0.8));
  WALLS.forEach((b) => block(b));
  FIXTURES.forEach((b) => block(b));

  const { shelf, wait, drive } = addFurniture(still, wx, wz);
  scene.add(shelf, wait);
  merge(still);
  merge(shelf);
  merge(wait);

  scene.add(new THREE.HemisphereLight('#f2f7fa', '#8d8a84', 1.5));
  const sun = new THREE.DirectionalLight('#fff6ea', 2.0);
  sun.position.set(7, 14, 8);
  sun.castShadow = true;
  sun.shadow.mapSize.set(1024, 1024);
  sun.shadow.radius = 4;
  sun.shadow.normalBias = 0.02;
  Object.assign(sun.shadow.camera, { left: -12, right: 12, top: 12, bottom: -12 });
  scene.add(sun);
  return { scene, shelf, wait, drive };
}

export type ViewState = Scenario & { line: boolean; takeaway: boolean };
type LabelSpec = [string, number, number, ((s: ViewState) => boolean)?];
const LABELS: LabelSpec[] = [
  ['Kitchen', 780, 420],
  ['Till', 450, 1150],
  ['Door', 842, 1745],
  ['Line at the door', 1150, 2090, (s) => !s.waitlist && s.line],
  ['Takeaway waits among tables', 1170, 760, (s) => !s.shelf && s.takeaway],
  ['Pickup shelf', 375, 1510, (s) => s.shelf],
  ['Waiting by phone', 330, 2210, (s) => s.waitlist],
];

export function createViews(containers: HTMLElement[], reduceMotion: boolean) {
  const room = buildRoom();
  const camera = new THREE.PerspectiveCamera(32, 1, 0.5, 200);
  let framed = false;

  const panes = containers.map((view, index) => {
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    const canvas = renderer.domElement;
    canvas.tabIndex = 0;
    canvas.setAttribute('role', 'img');
    canvas.setAttribute('aria-label', `${index ? 'With changes' : 'Today'}: 3D view of the cafe. Drag or use arrow keys to turn both views.`);
    const labelRenderer = new CSS2DRenderer();
    labelRenderer.domElement.className = 'labels';
    view.append(canvas, labelRenderer.domElement);

    const controls = new OrbitControls(camera, canvas);
    controls.enableDamping = !reduceMotion;
    controls.enablePan = false;
    controls.minPolarAngle = 0.15;
    controls.maxPolarAngle = 1.25; // never under the floor
    controls.minDistance = 12;
    controls.maxDistance = 90;
    canvas.style.touchAction = 'pan-y'; // a vertical swipe still scrolls the page on phones
    canvas.addEventListener('keydown', (e) => {
      const turn = ({ ArrowLeft: [-0.12, 0], ArrowRight: [0.12, 0], ArrowUp: [0, -0.08], ArrowDown: [0, 0.08] } as Record<string, number[]>)[e.key];
      if (!turn) return;
      e.preventDefault();
      const s = new THREE.Spherical().setFromVector3(camera.position);
      s.theta += turn[0];
      s.phi = THREE.MathUtils.clamp(s.phi + turn[1], controls.minPolarAngle, controls.maxPolarAngle);
      camera.position.setFromSpherical(s);
      controls.update();
    });

    // labels live in their own scene per pane: one DOM label cannot serve two views
    const labelScene = new THREE.Scene();
    const labels = LABELS.map(([text, px, py, when]) => {
      const el = document.createElement('div');
      el.className = 'label';
      el.textContent = text;
      const object = new CSS2DObject(el);
      object.position.set(wx(px), 1.4, wz(py));
      labelScene.add(object);
      return { object, when };
    });

    const group = new THREE.Group();
    room.scene.add(group);
    const people = createPeople(group, wx, wz, reduceMotion);

    new ResizeObserver(() => {
      const { clientWidth: w, clientHeight: h } = view;
      if (!w || !h) return;
      if (!framed) {
        framed = true;
        const aspect = w / h;
        const [distance, polar, turn] = aspect < 1.1 ? [Math.min(31.5 / Math.min(aspect, 1), 85), 0.62, 0.08] : [33, 0.75, 0.4];
        camera.position.setFromSphericalCoords(distance, polar, turn);
        controls.update();
      }
      renderer.setSize(w, h);
      labelRenderer.setSize(w, h);
    }).observe(view);

    return { view, renderer, labelRenderer, labelScene, labels, group, people, controls };
  });

  return {
    people: panes.map((p) => p.people),
    seatCount: SEATS.length,
    render(scenarios: ViewState[], seconds: number) {
      if (!reduceMotion) room.drive(seconds);
      panes[0].controls.update();
      panes.forEach((pane, i) => {
        const { clientWidth: w, clientHeight: h } = pane.view;
        if (!w || !h) return;
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        room.shelf.visible = scenarios[i].shelf;
        room.wait.visible = scenarios[i].waitlist;
        panes.forEach((other) => { other.group.visible = other === pane; });
        pane.labels.forEach((l) => { l.object.visible = l.when ? l.when(scenarios[i]) : true; });
        pane.renderer.render(room.scene, camera);
        pane.labelRenderer.render(pane.labelScene, camera);
      });
    },
  };
}
