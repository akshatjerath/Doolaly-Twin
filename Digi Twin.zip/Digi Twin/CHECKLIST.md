# Final checks, 27 Nov 2026

| Pass | Result | Evidence |
|---|---|---|
| 1. Ask (done criteria) | **Partly** | Build and static serving, same customers, labels: met. Frame rate not met or not proven (below). "Not cartoon" needs a stranger's view. |
| 2. Edge cases | **Partly pass** | In the built app: 0, 1, 30 seats; no arrivals; peak 80; switch shop; pause holds the clock; change hour; sliders mid-run; no console errors. Not tried: reduced motion, a minute-long hidden tab (the step is capped in code), extreme orbit, live window resize. |
| 3. Logic | **Pass** | `test/sim.test.ts`: matches the reference for 2, 14, 39 seats; identical arrival logs; no group lost or doubled; no shared seats. With both changes off, both panels read the same. |
| 4. Facts | **Partly** | Real values copied from `reference-twin.html`; not re-checked against Google Maps. Guesses tagged Assumed. |
| 5. Stranger | **Not done** | Needs a person. |
| 6. Open it | **Partly** | `dist/` served and used; console clean; phone size emulated, no sideways scroll. No real phone. |

Other checks

- Type check: pass. Unit tests: 9 of 9 pass.
- Lint: not set up.
- Lighthouse: not run. Only checked that every control has a name.
- Frame rate: about 31 fps read in the preview pane, below the 60 target. Cause unknown (the pane may cap it). Measure in a normal browser.
- `npm audit`: 0 in shipped packages. The test tool (vitest) still has advisories whose fix is a major upgrade, likely needing a newer Node.
- Security review: not run.
- Build warns that the script is over 500 kB (about 140 kB gzipped).
- Screenshots: `screenshots/`. The empty-room one predates later changes; "Today" and "With changes" share one image.
