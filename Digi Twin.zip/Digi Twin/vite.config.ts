// Relative base so dist/ works from any folder on a static host.
export default { base: './' };
