# Credits

- three.js (MIT licence)
- Vite, TypeScript, Vitest (build and test tools; MIT, Apache-2.0, MIT)
- No third-party 3D models or textures. All geometry is built in code.
- Floor plan: `Floor plan.png`, supplied by the project owner. Origin and accuracy not verified.
- Data: see `source` and `retrievedOn` in `data/*.json`.
