# Prompt for Claude Code / Codex: realistic 3D waiting-zone twin

Paste everything below the line into the agent. Put `reference-twin.html` (the current 2D-canvas version) in the project folder first. It holds the simulation logic and the real data.

---

## 0. Role and goal

You are a senior creative technologist. Build a realistic 3D digital twin of one cafe's customer waiting zone, to show the cafe owner what a waitlist and a pickup shelf would change.

**One-sentence restatement (confirm in your first message):** Two linked 3D views of Boojee Cafe, Bandra West, Mumbai, "Today" and "With changes". They run the same simulated customers, so any difference comes only from the two changes.

**Real goal:** an owner who has never seen a simulation looks at it for 30 seconds and understands where people stand, who gives up and what would change. A design-school assessor should find it credible and well made.

**Done when ALL of these pass:**
1. `npm run dev` opens the app. `npm run build` produces a `dist/` that works from a static host.
2. The scene reads as an architectural scale model, not a toy and not a game. A stranger shown a screenshot does not say "cartoon".
3. Both panes use identical seeded customers. Changing nothing but the scenario toggles changes the numbers.
4. 60 fps on a mid laptop with 40 people on screen. 30 fps minimum on a mid phone.
5. Every number is labelled **Real** or **Assumed**. Nothing is invented.
6. You have opened the running app, looked at screenshots and fixed what was wrong (section 6).

## 1. Understand first (do this before writing code)

Sort the brief into three lists and show them to me.

**Stated**
- Venue: Boojee Cafe, Shop No 6, 29 New Kantwadi Rd, off Perry Cross Rd, Bandra West. Open 7 AM to 11 PM. One shop, one owner.
- Two panes, a shared seed, two scenarios: (a) waitlist with a quoted wait, so people wait off-site by phone; (b) pickup shelf with a ready board, so takeaway customers stand at the shelf.
- Real data: Saturday busyness by hour (Google Maps "popular times", relative to the shop's own weekly peak, not a head count) and the live status. Both are in `reference-twin.html`.
- Speed menu: Crawl 0.5, Very slow 1 (default), Slow 2.5, Normal 6, Fast 15, in simulated minutes per real second. Pause, Restart, New random day, Run 2 hours.

**Implied**
- Light and dark UI around the canvases. Touch orbit on phones. `prefers-reduced-motion` respected. Keyboard accessible controls.
- Plain-language labels. No jargon. The owner is not technical.

**Unknown (do not guess, mark as Assumed or ask)**
- The real floor plan. Seat count (14 is a placeholder). Order and prep times. Arrivals at peak. Stay time. How much a visible line puts people off.
- Whether I can supply photos or a sketch of the floor.

**Hidden-constraint check** (state your answer to each in one line): format, audience, deadline, scope (what is OUT), existing work to match, rules, cost of being wrong.

If anything in "Unknown" blocks a decision that is expensive to undo, ask me ONE question with options. Otherwise state your assumption in a line and continue.

## 2. Plan (show me before building)

Work back from the finished app. Give me a plan in this format and wait for my "go":

```
Goal: ...
Done when: ...
1. <module> -> produces <output> -> check: <how I verify>
2. <module> -> needs 1 -> produces <output> -> check: ...
```

Order by dependency. Do the riskiest piece first: **the look of the empty room**. If that does not look right, nothing else matters. Plan a checkpoint after every module. Work on a git branch so every step is reversible. Gather material (data, models, references) before building.

Modules I expect, change them if you can justify it:
1. Project scaffold and tooling
2. Visual direction and the empty room (**approval gate**)
3. Furniture and props
4. People: model, ring states, animation
5. Simulation core ported from the reference, with tests
6. Wiring: sim drives the scene
7. UI: controls, metrics, Real/Assumed panels
8. Performance and mobile
9. Accessibility and polish
10. Final checks and handover notes

## 3. Ideation (before any modelling)

Propose **three** distinct visual directions. For each give: a one-line idea, palette (hex), materials, lighting, camera, how people are drawn, and what it costs in effort. Examples of the range, not a menu:
- **A. White card model:** matte white walls, light oak floor, soft shadows, muted ghost-like people.
- **B. Warm interior render:** real materials, glass front, evening light, depth of field.
- **C. Technical overlay:** model in greys with data drawn in colour, like an architect's diagram.

Then **pick one** and say why in three lines, tied to the real goal. Rules for every direction:
- Not cartoon. No bright primary colours, no outlines, no toy proportions, no emoji.
- One accent colour. Neutral base. People in muted tones; their state is shown by a soft ground ring: amber = waiting for a seat, blue = waiting for takeaway, grey = seated, red = walked away.
- The cutaway is low walls (about 1.1 m) on the near sides and a glass storefront on the street side, so the inside is visible.
- Do NOT use the beige-cream-brass default palette.

## 4. Build

### 4.1 Stack
Vite + TypeScript (strict) + Three.js. No React. Orbit controls with damping and a limited polar angle (camera never goes under the floor). ACESFilmic tone mapping, sRGB output, soft shadows, one key light plus hemisphere fill, contact shadows or SSAO. Labels are HTML overlays (CSS2DRenderer), not 3D text. Instance people and chairs with `InstancedMesh`.

### 4.2 Scene
- Room 13 m x 9 m, counter along the back wall with till points, door on the front wall, 14 seats on round tables of two with stools or chairs, pickup shelf on the left wall (only in the "With changes" pane), pavement and street outside, an off-site waiting area for the waitlist (bench and planters), now and then a passing car.
- Free models are fine (Kenney, Quaternius, Poly Pizza, check each licence and list them in `CREDITS.md`). Otherwise clean beveled geometry.
- Two scenes share one geometry and material set. Only the scenario flags differ.

### 4.3 People
- Simple mannequin or capsule figures, no faces. Walk at about 1.2 m/s along waypoints. No teleporting. A short seat/stand transition. Slight sway while walking.
- Position follows a path from where they entered to their target. Targets by state are in the reference's `draw()` function.

### 4.4 Simulation
**Port the logic from `reference-twin.html` exactly. Do not redesign it.** It sits between the `/* SIM-START */` and `/* SIM-END */` markers.
- Discrete-time queue simulation using **common random numbers**: one seeded RNG, every party draws its random numbers on arrival, so both panes see the same customers.
- Parties of 1 to 4, dine-in or takeaway. Seats, tills, prep capacity as inputs.
- "Today": a line at the door; takeaway customers wait among the tables; some walk away when the visible line is long.
- "With changes": waitlist with a quoted wait (people wait off-site, patience rises); pickup shelf and ready board.
- The quoted wait walks the queue using seated parties' leave times and finds when a party of two fits.
- Put the sim in its own module with **no Three.js imports**. Write unit tests: determinism (same seed, same result), both panes get identical arrivals, and no party is ever lost or counted twice.
- Metrics per pane: parties in line, walk-aways per hour, average wait for a seat, slowest 1 in 10 waits, seats in use %, people standing among tables, average time to get a takeaway, quoted wait error.
- Keep this honest note on screen: a waitlist can raise the average wait for seated parties, because people who would have left now stay.

### 4.5 UI
Controls (play/pause, restart, new random day, run 2 hours, speed), the sliders for the inputs, the busyness chart for Saturday with the simulated hour highlighted, the metrics tables, and a "Real vs Assumed" section. Amber **Assumed** tags beside every guessed number. Layout: the two panes side by side, equal height, aligned rows. Stack on narrow screens.

### 4.6 Data
Move the real data out of the code into `data/boojee.json` and `data/angry-toast.json` with a `source` and `retrievedOn` field. Note the busyness values were read off the chart by eye (about plus or minus 5 points). The live-status chip is a snapshot, not live. Do not claim it updates.

## 5. Iterate (the loop, run it after every module)

1. Run the app. Take screenshots with Playwright at 1440x900 and 390x844, in light and dark mode, at three camera angles.
2. Look at them yourself. Write down what is wrong in plain words ("walls too thick", "people the same size as chairs", "label hides the door").
3. Fix the top three problems. Take the screenshots again. Compare before and after.
4. Stop iterating on a module only when two passes in a row find nothing new.
5. After modules 2, 4 and 6, show me the screenshots and wait. I will redirect early.

## 6. Check and fix (final pass, do not skip any)

Run these in order. If a pass finds a fault, fix it and rerun that pass. Do not report done while one fails.

1. **Ask pass.** Re-read sections 0 and 1. Tick each item. List anything unmet.
2. **Edge cases.** Zero seats, 1 seat, 30 seats. Zero arrivals. Peak load with a long line. Pause then resume. Change a slider mid-run. Switch shop. Resize the window. Tab hidden for a minute then shown (no huge time jump). Orbit to extreme angles. Reduced-motion on.
3. **Logic.** The shared-seed claim: diff the arrival logs of both panes, they must match. Conservation: people in, seated, left, walked away add up. Numbers shown equal numbers computed.
4. **Facts.** Every Real value matches its source. Every Assumed value is tagged. No invented figure, standard or claim anywhere in the UI. Check the arithmetic.
5. **Stranger pass.** Show the screen to someone with no context. Can they say, within 10 seconds, what the two panes are and which is better? Fix the labels until they can.
6. **Open it.** Run `npm run build`, serve `dist/`, open it, click everything. Test on a phone (or device emulation). Check the console is clean and frame rate with the performance panel.

Then run: type check, lint, unit tests, and a Lighthouse accessibility check (contrast, focus order, labels). Fix what fails.

## 7. Rules for you

- Lead each message with the result, then reasoning. No story of the work.
- Cheap-to-redo choices: decide, state in one line, continue. Costly or irreversible: ask one question with options.
- Never fill a gap with an invented fact. A stated assumption is fine; a hidden one is a fault.
- If two requirements conflict, name the conflict, then rank: hard limits first, then the real goal. Do not quietly drop one.
- Stage only. Do not commit, push or deploy without my "go".

## 8. Deliverables

- Running project, `dist/`, `README.md` (how to run, how to swap the venue, how to change the data), `CREDITS.md`, `data/*.json`, `tests/`.
- `CHECKLIST.md` with the six passes and the result of each (pass or fail, evidence).
- Five screenshots: empty room, Today at peak, With changes at peak, mobile, dark mode.
- A short "what is still a guess" list for the owner visit.

**Start now:** restate the task in one sentence, give me the three lists from section 1, then the plan from section 2. Stop and wait for my go.
