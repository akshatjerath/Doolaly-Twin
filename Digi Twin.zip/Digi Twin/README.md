# Waiting Zone Twin

Two linked 3D views of a cafe's waiting zone: **Today** and **With changes** (waitlist, pickup shelf), fed the same simulated customers.

## Run

```
npm install
npm run dev       # development
npm run build     # type check, then dist/ for any static host
npm run preview   # serve dist/
npm test
```

Needs Node 20.10 or newer. `dist/` must be served over http; opening `index.html` as a file will not work.

## Change the data

`data/*.json`: real values (`saturdayBusyness`, `facts`, `statusSnapshot`, with `source` and `retrievedOn`) and guesses (`assumed`). Replace guesses after counting on site.

## Swap the venue

1. Add `data/<shop>.json` with the same fields and list it in `SHOPS` in `src/main.ts`.
2. Room: `src/plan.ts` holds walls, furniture and seats in floor-plan pixels. `src/walk.ts` holds aisles and waiting spots. Both are specific to Boojee Cafe. Another shop shows Boojee's room, and the page says so.

## Files

| File | Holds |
|---|---|
| `src/sim.ts` | Simulation, ported from `reference-twin.html` |
| `src/sync.ts` | Who stands or sits where |
| `src/walk.ts`, `src/people.ts` | Walking and figures |
| `src/scene.ts`, `src/furniture.ts`, `src/plan.ts` | The room |
| `src/main.ts`, `index.html` | Controls and numbers |

## Known limits

- Walking is 1.2 m/s at the default speed and faster when the clock is faster.
- Bench seats are reached straight across their table.
- Only a fixed number of waiting spots are drawn; counts in the panels are complete.
- The model counts seats, not tables, so a group may be split in real life where the model fits it.

## What is still a guess (count these on the visit)

- [ ] Seats (39 counted from the drawing) and whether the drawing is the real room
- [ ] Room size
- [ ] Groups arriving per hour at the busiest time
- [ ] How long a group stays
- [ ] Share of takeaway, order time, people at the till, prep time
- [ ] How long people wait before leaving, and how often they walk past a line
- [ ] Whether people would wait longer when called by phone
