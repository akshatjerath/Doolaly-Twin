import { expect, test } from 'vitest';
import { advance, AMONG, DOOR_LINE, GONE, route, SEAT_PATHS, SPEED, type Point } from '../src/walk';

test('a route ends at the destination, also back along the same path', () => {
  for (const [from, to] of [[GONE, SEAT_PATHS[0]], [DOOR_LINE[3], SEAT_PATHS[20]], [AMONG[17], AMONG[1]], [SEAT_PATHS[5], GONE], [DOOR_LINE[4], DOOR_LINE[0]]]) {
    const at: Point = [...from[from.length - 1]];
    advance(at, route(from, to), 1e9);
    expect(at).toEqual(to[to.length - 1]);
  }
});

test('nobody moves further than their speed allows', () => {
  const at: Point = [...GONE[0]];
  const todo = route(GONE, SEAT_PATHS[0]);
  for (let i = 0; i < 2000 && todo.length; i++) {
    const [x, y] = at;
    advance(at, todo, SPEED / 60);
    expect(Math.hypot(at[0] - x, at[1] - y)).toBeLessThanOrEqual(SPEED / 60 + 1e-6);
  }
  expect(todo).toHaveLength(0);
});
