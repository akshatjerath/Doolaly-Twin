import { expect, test } from 'vitest';
import boojee from '../data/boojee.json';
import toast from '../data/angry-toast.json';
import { BOUNDS, FIXTURES, SEATS, WALLS }from '../src/plan';

test('every block has a positive size and sits inside the plot', () => {
  for (const [x0, y0, x1, y1, h] of [...WALLS, ...FIXTURES]) {
    expect(x1 > x0 && y1 > y0 && h > 0).toBe(true);
    expect(x0 >= BOUNDS.x0 && x1 <= BOUNDS.x1 && y0 >= BOUNDS.y0 && y1 <= BOUNDS.patioY).toBe(true);
  }
});

test('the drawn seats match the seat count in the data, all indoors', () => {
  expect(SEATS).toHaveLength(boojee.assumed.seats);
  for (const [x, y] of SEATS) expect(x > BOUNDS.x0 && x < BOUNDS.x1 && y > BOUNDS.y0 && y < BOUNDS.y1).toBe(true);
});

test('each shop has one busyness value per open hour and a source', () => {
  for (const shop of [boojee, toast]) {
    expect(shop.saturdayBusyness).toHaveLength(16);
    expect(shop.source && shop.retrievedOn).toBeTruthy();
  }
});
