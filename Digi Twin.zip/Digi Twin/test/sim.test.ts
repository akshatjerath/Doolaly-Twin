import { expect, test } from 'vitest';
import reference from '../reference-twin.html?raw';
import { DT, Sim, type Config, type Party, type Scenario } from '../src/sim';
import { createSync } from '../src/sync';

const block = reference.slice(reference.indexOf('/* SIM-START */'), reference.indexOf('/* SIM-END */'));
const RefSim = new Function(`${block}; return Sim;`)() as typeof Sim;

const cfg: Config = { lambda: 40, seats: 14, dwell: 45, take: 0.3, order: 1, tills: 1, prep: 8, patience: 25, balk: 0.03, boost: 1.25 };
const today: Scenario = { waitlist: false, shelf: false };
const changed: Scenario = { waitlist: true, shelf: true };
const run = (sim: Sim, minutes: number) => {
  for (let i = 0; i < minutes / DT; i++) sim.step();
  return sim;
};

test('matches the reference simulation for 2 or more seats', () => {
  for (const seats of [2, 14, 39]) {
    for (const scen of [today, changed]) {
      for (const seed of [1, 7, 99]) {
        const config = { ...cfg, seats };
        expect(run(new Sim(config, scen, seed), 600).summary()).toEqual(run(new RefSim(config, scen, seed), 600).summary());
      }
    }
  }
});

test('both sides get exactly the same arrivals', () => {
  const logs = [today, changed].map((scen) => {
    const sim = new Sim(cfg, scen, 7);
    const log: string[] = [];
    const arrive = sim.arrive.bind(sim);
    sim.arrive = (p: Party) => {
      log.push([p.id, p.size, p.take, p.arr, p.pU, p.bU, p.dU, p.oU, p.rU].join());
      arrive(p);
    };
    run(sim, 600);
    return log;
  });
  expect(logs[0].length).toBeGreaterThan(100);
  expect(logs[0]).toEqual(logs[1]);
});

test('no group is lost or counted twice, including 0 and 1 seat and no arrivals', () => {
  for (const seats of [0, 1, 30]) {
    for (const lambda of [0, 60]) {
      for (const scen of [today, changed]) {
        const sim = run(new Sim({ ...cfg, seats, lambda }, scen, 3), 600);
        const st = sim.st;
        expect(st.arrDine).toBe(st.balk + st.renege + st.seatedN + sim.dineQ.length);
        expect(st.arrTake).toBe(sim.tillQ.length + sim.tills.filter((t) => t.p).length + sim.prep.length + st.takeDone);
        expect(sim.seatsUsed).toBeLessThanOrEqual(seats);
        for (const value of Object.values(sim.summary())) if (typeof value === 'number') expect(Number.isFinite(value)).toBe(true);
      }
    }
  }
});

test('nobody shares a seat, and a group that gives up is shown walking away', () => {
  const held = new Map<number, string>();
  let leftShown = 0;
  const sync = createSync({
    send(id, path, state) {
      if (state === 'left') leftShown++;
      if (state === 'seated' && path.length > 1) held.set(id, String(path.at(-1)));
      else held.delete(id);
    },
    clear: () => held.clear(),
  });
  const sim = new Sim({ ...cfg, seats: 14, lambda: 60 }, today, 5);
  for (let i = 0; i < 2000; i++) {
    sim.step();
    sync.update(sim);
    expect(new Set(held.values()).size).toBe(held.size);
    expect(held.size).toBe(sim.seatsUsed);
  }
  expect(sim.st.renege).toBeGreaterThan(0);
  expect(leftShown).toBeGreaterThan(0);
});
